#include "eraser.h"

// Your code here to implement the functions in eraser.h

// Eraser GetColor() function returns only white color.
graphics::Color Eraser::GetColor() const{
    return color_for_earser;
}
