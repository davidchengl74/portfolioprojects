# Milestone 6

## Description
Describe what you did for this milestone in your own words.

For this project, combined paint project 4 and paint project 5 with button slection shown on the program for drawing. 

## Challenges encountered
Describe the challenges you encountered while working on this milestone of the project.

For this project, had some diffuculty in implementing the buttonlisenter and mouse event lisetner for the project. 

## Things I've learned
What is the most important thing you've learned from this milestone in the project?

Adding the button functionality with the program.
